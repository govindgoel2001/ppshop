import { useState } from 'react';
import './TestingCertificates.css';

const certificates = [
  {
    "product": "BAC Water",
    "testType": "Qualitative analysis",
    "date": "2026-02-16",
    "resultSummary": "Benzyl Alcohol: 9.33 mg/ml",
    "image": "/img/testing/bac-water-hplc.png",
    "alt": "Bacteriostatic water test report"
  },
  {
    "product": "BPC-157 10mg",
    "testType": "Peptide assessment",
    "date": "2026-02-09",
    "resultSummary": "BPC-157: 11.72 mg; purity: 99.765%",
    "image": "/img/testing/bpc10-hplc.png",
    "alt": "BPC-157 10mg HPLC test report"
  },
  {
    "product": "Retatrutide 10mg",
    "testType": "Peptide assessment",
    "date": "2025-10-29",
    "resultSummary": "Retatrutide: 10.13 mg; purity: 99.790%",
    "image": "/img/testing/reta10-hplc.png",
    "alt": "Retatrutide 10mg HPLC test report"
  },
  {
    "product": "Tirzepatide 20mg",
    "testType": "Peptide assessment",
    "date": "2025-10-29",
    "resultSummary": "Tirzepatide: 21.65 mg; purity: 99.505%",
    "image": "/img/testing/tirz20-hplc.png",
    "alt": "Tirzepatide 20mg HPLC test report"
  },
  {
    "product": "GHK-Cu 100mg",
    "testType": "GHK-Cu analysis",
    "date": "2026-04-10",
    "resultSummary": "GHK-Cu: 103.80 mg; purity: 99.814%",
    "image": "/img/testing/ghkcu100-hplc.png",
    "alt": "GHK-Cu 100mg HPLC test report"
  },
  {
    "product": "Tesamorelin 10mg",
    "testType": "Peptide assessment",
    "date": "2026-01-14",
    "resultSummary": "Tesamorelin: 10.43 mg / 10.36 mg; purity: 99.426% / 99.302%",
    "image": "/img/testing/tesa-hplc.png",
    "alt": "Tesamorelin 10mg HPLC test report"
  },
  {
    "product": "GLOW 70mg",
    "testType": "Blend assessment",
    "date": "2026-02-17",
    "resultSummary": "GHK-Cu: 55.25 mg; BPC-157: 11.01 mg; TB-500: 10.18 mg",
    "image": "/img/testing/glow70-hplc.png",
    "alt": "GLOW 70mg blend test report"
  },
  {
    "product": "Semax 10mg",
    "testType": "Semax analysis",
    "date": "2026-04-10",
    "resultSummary": "Semax: 10.56 mg; purity: 99.290%",
    "image": "/img/testing/semax10-hplc.png",
    "alt": "Semax 10mg HPLC test report"
  }
];

export default function TestingCertificates() {
  const [active, setActive] = useState(null);
  return (
    <section className="testing-section" aria-labelledby="testing-title">
      <div className="testing-head">
        <p className="testing-eyebrow">Third-party testing</p>
        <h2 id="testing-title">Certificates of Analysis</h2>
        <p>For research use only. Not for human consumption. Test reports are shown for transparency and are not medical advice.</p>
      </div>
      <div className="testing-grid">
        {certificates.map((cert) => (
          <article className="testing-card" key={cert.product}>
            <div>
              <h3>{cert.product}</h3>
              <p className="testing-meta">{cert.testType} · {cert.date}</p>
              <p>{cert.resultSummary}</p>
            </div>
            <button type="button" onClick={() => setActive(cert)}>View Certificate</button>
          </article>
        ))}
      </div>
      {active && (
        <div className="testing-modal" role="dialog" aria-modal="true" aria-label={active.product + ' certificate'} onClick={() => setActive(null)}>
          <div className="testing-modal-panel" onClick={(event) => event.stopPropagation()}>
            <button type="button" className="testing-close" onClick={() => setActive(null)} aria-label="Close certificate">×</button>
            <img src={active.image} alt={active.alt} />
          </div>
        </div>
      )}
    </section>
  );
}
