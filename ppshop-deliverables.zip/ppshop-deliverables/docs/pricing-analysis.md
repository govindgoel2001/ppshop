# Pricing Analysis

Internal working document. Do not publish this file as customer-facing content.

All customer-facing Athena BioLabs content should continue to state: **For research use only. Not for human consumption.**

## Assumptions

- Exchange rate: `USD_INR = 94.869`, checked on May 1, 2026.
- `PACKAGING_COST_PER_ORDER = Rs. 120`
- `SHIPPING_COST_PER_ORDER = Rs. 180`
- `PAYMENT_GATEWAY_PERCENT = 2%`
- `AVG_VIALS_PER_ORDER = 2`
- Supplier kit size: 10 vials per kit.
- BAC Water uses the 10ml cost line to match the current live Athena listing. If selling 3ml BAC Water, use USD 1.00 per vial instead.
- Missing Athena prices are marked `Not listed` when the product was not present in the current public catalogue scrape.

## Reusable Formula

```text
supplier_cost_per_vial_usd = supplier_cost_per_kit_usd / 10
supplier_cost_per_vial_inr = supplier_cost_per_vial_usd * USD_INR
ops_cost_per_vial = (PACKAGING_COST_PER_ORDER + SHIPPING_COST_PER_ORDER) / AVG_VIALS_PER_ORDER
payment_fee_per_vial = selling_price * PAYMENT_GATEWAY_PERCENT
total_landed_cost_per_vial = supplier_cost_per_vial_inr + ops_cost_per_vial + payment_fee_per_vial
gross_profit_per_unit = selling_price - total_landed_cost_per_vial
gross_margin_percent = gross_profit_per_unit / selling_price
target_price = (supplier_cost_per_vial_inr + ops_cost_per_vial) / (1 - PAYMENT_GATEWAY_PERCENT - target_margin)
```

## Current Product Economics

| Product | Supplier cost per kit | Supplier cost per vial | Packaging/order | Shipping/order | Payment fee estimate | Total landed cost/vial | Current Athena price | Gross profit/unit | Gross margin | Suggested conservative | Suggested standard | Suggested premium | Notes |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|
| TIRZ 20mg | USD 108 | USD 10.80 / Rs. 1,025 | Rs. 120 | Rs. 180 | Rs. 76 | Rs. 1,251 | Rs. 3,800 | Rs. 2,549 | 67.1% | Rs. 2,450 | Rs. 3,090 | Rs. 4,195 | Current pricing is strong and close to premium positioning. |
| RETA 10mg | USD 130 | USD 13.00 / Rs. 1,233 | Rs. 120 | Rs. 180 | Rs. 58 | Rs. 1,441 | Rs. 2,899 | Rs. 1,458 | 50.3% | Rs. 2,880 | Rs. 3,640 | Rs. 4,940 | Current pricing is conservative; standard pricing has room to move upward if quality proof is visible. |
| RETA 20mg | USD 198 | USD 19.80 / Rs. 1,878 | Rs. 120 | Rs. 180 | Rs. 90 | Rs. 2,118 | Rs. 4,500 | Rs. 2,382 | 52.9% | Rs. 4,225 | Rs. 5,340 | Rs. 7,245 | Fair but still below a premium target. |
| GHK-CU 50mg | USD 50 | USD 5.00 / Rs. 474 | Rs. 120 | Rs. 180 | Rs. 30 | Rs. 654 | Rs. 1,500 | Rs. 846 | 56.4% | Rs. 1,300 | Rs. 1,645 | Rs. 2,230 | Fair; low absolute profit means bundle strategy may matter more than headline price. |
| SEMAX 10mg | USD 55 | USD 5.50 / Rs. 522 | Rs. 120 | Rs. 180 | Unknown | Unknown | Not listed | Unknown | Unknown | Rs. 1,400 | Rs. 1,770 | Rs. 2,400 | Needs current selling price before margin call. |
| TESA 10mg | USD 158 | USD 15.80 / Rs. 1,499 | Rs. 120 | Rs. 180 | Unknown | Unknown | Not listed | Unknown | Unknown | Rs. 3,435 | Rs. 4,340 | Rs. 5,890 | Indian competitors price Tesamorelin much higher, so avoid underpricing if COA-backed. |
| GLOW 70mg | USD 180 | USD 18.00 / Rs. 1,708 | Rs. 120 | Rs. 180 | Unknown | Unknown | Not listed | Unknown | Unknown | Rs. 3,870 | Rs. 4,890 | Rs. 6,635 | Likely a premium bundle candidate if positioned around third-party test transparency. |
| BAC Water 10ml | USD 25 | USD 2.50 / Rs. 237 | Rs. 120 | Rs. 180 | Rs. 16 | Rs. 403 | Rs. 799 | Rs. 396 | 49.5% | Rs. 805 | Rs. 1,020 | Rs. 1,385 | Current price is fair/conservative; can be used as an order-builder. |

## Pricing Takeaways

- TIRZ 20mg is already healthy at roughly 67% gross margin under the assumptions above.
- RETA 10mg and RETA 20mg are viable but not premium-priced relative to India-market alternatives.
- GHK-CU 50mg is fair, but the absolute rupee profit is modest.
- BAC Water is priced near the conservative target; it should help conversion and bundling more than margin expansion.
- TESA 10mg, GLOW 70mg, and SEMAX 10mg need live Athena selling prices before a final margin call.

## Values To Confirm

- Actual packaging cost per shipped order.
- Actual Delhivery or courier cost by zone and cold-chain requirement.
- Actual payment method mix: UPI only, card, gateway, COD, or manual transfer.
- Average vials per order from real order history.
- Whether BAC Water SKU is 3ml, 10ml, or both.
